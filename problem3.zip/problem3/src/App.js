import React from 'react';

import './App.css';
import {
  BrowserRouter,
  Route,
  Redirect,
  Switch
} from 'react-router-dom';

// Components
import Container from './components/Container';

const App = () => (
  
  <BrowserRouter>
    <div className="container">
      <Switch>
        <Route exact path='/' render={ () => <Redirect to={"/photos-gallery"} /> } />
        <Route exact path="/photos-gallery" component={Container} />
      </Switch> 
    </div>
  </BrowserRouter>
)

export default App;
