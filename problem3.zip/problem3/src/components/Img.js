import React from 'react';

const Img = props => (
	<div className="images">
		<li className="img-wrap">
			<img src={props.url} alt=""/>
		</li>	
		<span className="title">{props.title}</span>
	</div>
	
);

export default Img;